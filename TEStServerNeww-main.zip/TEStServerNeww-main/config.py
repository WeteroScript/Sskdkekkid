import os
import logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

# ========== ЛОГИРОВАНИЕ ==========
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ========== ТОКЕН ==========
API_TOKEN = os.getenv('BOT_TOKEN')
if not API_TOKEN:
    raise ValueError("❌ BOT_TOKEN не установлен!")

# ========== БОТ ==========
bot = Bot(token=API_TOKEN)
dp = Dispatcher(storage=MemoryStorage())

# ========== АДМИНЫ ==========
ADMIN_IDS = [5877790074, 1218587495]

# ========== ПУТИ ==========
DATA_DIR = os.getenv('SHARED_DIR', '/app/shared')
if not os.path.exists(DATA_DIR):
    DATA_DIR = '.'

os.makedirs(DATA_DIR, exist_ok=True)

USERS_FILE = os.path.join(DATA_DIR, 'users_data.json')
BUSINESS_FILE = os.path.join(DATA_DIR, 'business.json')
AUCTION_FILE = os.path.join(DATA_DIR, 'auction.json')
SETTINGS_FILE = os.path.join(DATA_DIR, 'settings.json')
PROMOCODES_FILE = os.path.join(DATA_DIR, 'promocodes.json')
INVENTORY_FILE = os.path.join(DATA_DIR, 'inventory.json')
DISABLED_FUNCTIONS_FILE = os.path.join(DATA_DIR, 'disabled_functions.json')

# ========== КОНСТАНТЫ ==========
CHANNEL_ID = "-1004461974511"
PROMO_CHANNEL_ID = "-1003853479476"

# ========== РЕСУРСЫ ДЛЯ ШАХТЫ ==========
MINE_RESOURCES = [
    {"name": "Красный алмаз", "price": 50000000000, "chance": 0.0005},
    {"name": "Цветной алмаз", "price": 10000000000, "chance": 0.001},
    {"name": "Красная шпинель", "price": 5000000000, "chance": 0.004},
    {"name": "Александрит", "price": 2500000000, "chance": 0.007},
    {"name": "Рубин", "price": 1500000000, "chance": 0.015},
    {"name": "Падпараджа", "price": 750000000, "chance": 0.05},
    {"name": "Демантоид", "price": 150000000, "chance": 0.10},
    {"name": "Черный опал", "price": 10000000, "chance": 0.20},
    {"name": "Танзанит", "price": 5000000, "chance": 0.25},
    {"name": "Шпинель", "price": 1500000, "chance": 0.30}
]

# ========== РЕСУРСЫ ДЛЯ ФЕРМЫ ==========
FARM_RESOURCES = [
    {"name": "Молоко", "price": 8000000, "min": 1, "max": 5},
    {"name": "Сено", "price": 6000000, "min": 1, "max": 5},
    {"name": "Яйца", "price": 5000000, "min": 1, "max": 5},
    {"name": "Пшеница", "price": 3000000, "min": 1, "max": 5},
    {"name": "Мясо", "price": 10000000, "min": 1, "max": 3}
]

# ========== БИЗНЕС ==========
BUSINESS_CONFIG = {
    "auto_mine": {
        "name": "Авто-Шахта",
        "price": 30000000000,
        "max_owners": 2,
        "emoji": "⛏️",
        "profit_type": "resources",
        "resources": [
            {"name": "Красный алмаз", "chance": 0.05},
            {"name": "Цветной алмаз", "chance": 0.08},
            {"name": "Рубин", "chance": 0.15},
            {"name": "Александрит", "chance": 0.10},
            {"name": "Падпараджа", "chance": 0.12},
            {"name": "Демантоид", "chance": 0.15},
            {"name": "Черный опал", "chance": 0.20},
            {"name": "Танзанит", "chance": 0.25},
            {"name": "Шпинель", "chance": 0.30}
        ],
        "min_resources": 1,
        "max_resources": 3,
        "cooldown": 5400
    },
    "tech_center": {
        "name": "Технический центр",
        "price": 20000000000,
        "max_owners": 5,
        "emoji": "🔧",
        "profit_type": "money",
        "profit_min": 100000000,
        "profit_max": 350000000,
        "cooldown": 12600
    },
    "tire_center": {
        "name": "Шиномонтажный центр",
        "price": 15000000000,
        "max_owners": 5,
        "emoji": "🛞",
        "profit_type": "money",
        "profit_min": 75000000,
        "profit_max": 150000000,
        "cooldown": 9000
    },
    "styling_center": {
        "name": "Стайлинг центр",
        "price": 15000000000,
        "max_owners": 5,
        "emoji": "🎨",
        "profit_type": "money",
        "profit_min": 75000000,
        "profit_max": 150000000,
        "cooldown": 9000
    },
    "shop_24": {
        "name": "Магазин 24/7",
        "price": 1000000000,
        "max_owners": 20,
        "emoji": "🏪",
        "profit_type": "money",
        "profit_min": 30000000,
        "profit_max": 70000000,
        "cooldown": 3600
    }
}

# ========== МАШИНЫ ДЛЯ АУКЦИОНА ==========
AUCTION_CARS = {
    # ★★★★★ Экзотические
    "RcCar": {"stars": 5, "rarity": "Экзотическая", "base_price": 5000000000, "chance": 0.005, "start_bid": 10000000},
    "Игрушечный вертолетик": {"stars": 5, "rarity": "Экзотическая", "base_price": 5000000000, "chance": 0.005, "start_bid": 10000000},
    "Лимузин": {"stars": 5, "rarity": "Экзотическая", "base_price": 120000000, "chance": 0.005, "start_bid": 10000000},
    "Монстр трак": {"stars": 5, "rarity": "Экзотическая", "base_price": 150000000, "chance": 0.005, "start_bid": 10000000},
    "БРДМ": {"stars": 5, "rarity": "Экзотическая", "base_price": 250000000, "chance": 0.005, "start_bid": 10000000},
    "Вертолёт": {"stars": 5, "rarity": "Экзотическая", "base_price": 450000000, "chance": 0.005, "start_bid": 10000000},
    "Танк": {"stars": 5, "rarity": "Экзотическая", "base_price": 1200000000000, "chance": 0.005, "start_bid": 10000000},
    "Истребитель": {"stars": 5, "rarity": "Экзотическая", "base_price": 3500000000000, "chance": 0.005, "start_bid": 10000000},
    
    # ★★★★☆ Легендарные
    "DeLorean DMC-12": {"stars": 4, "rarity": "Легендарная", "base_price": 250000000, "chance": 0.05, "start_bid": 200000000},
    "Zenvo ST1": {"stars": 4, "rarity": "Легендарная", "base_price": 400000000, "chance": 0.05, "start_bid": 200000000},
    "Koenigsegg CCX": {"stars": 4, "rarity": "Легендарная", "base_price": 450000000, "chance": 0.05, "start_bid": 200000000},
    "Jaguar E-Type Lightweight": {"stars": 4, "rarity": "Легендарная", "base_price": 450000000, "chance": 0.05, "start_bid": 200000000},
    "Ferrari 365 GTB/4 Daytona": {"stars": 4, "rarity": "Легендарная", "base_price": 500000000, "chance": 0.05, "start_bid": 200000000},
    "Porsche 959": {"stars": 4, "rarity": "Легендарная", "base_price": 550000000, "chance": 0.05, "start_bid": 200000000},
    "Aston Martin DB4 GT": {"stars": 4, "rarity": "Легендарная", "base_price": 550000000, "chance": 0.05, "start_bid": 200000000},
    "Shelby Cobra 427": {"stars": 4, "rarity": "Легендарная", "base_price": 550000000, "chance": 0.05, "start_bid": 200000000},
    "Lamborghini Miura": {"stars": 4, "rarity": "Легендарная", "base_price": 600000000, "chance": 0.05, "start_bid": 200000000},
    "Ford GT40": {"stars": 4, "rarity": "Легендарная", "base_price": 600000000, "chance": 0.05, "start_bid": 200000000},
    "Lamborghini Reventón": {"stars": 4, "rarity": "Легендарная", "base_price": 650000000, "chance": 0.05, "start_bid": 200000000},
    "McLaren F1 GTR": {"stars": 4, "rarity": "Легендарная", "base_price": 650000000, "chance": 0.05, "start_bid": 200000000},
    "Ferrari F40 Competizione": {"stars": 4, "rarity": "Легендарная", "base_price": 700000000, "chance": 0.05, "start_bid": 200000000},
    "Alfa Romeo 33 Stradale": {"stars": 4, "rarity": "Легендарная", "base_price": 700000000, "chance": 0.05, "start_bid": 200000000},
    "Bugatti Veyron Super Sport": {"stars": 4, "rarity": "Легендарная", "base_price": 750000000, "chance": 0.05, "start_bid": 200000000},
    "Pagani Zonda Cinque": {"stars": 4, "rarity": "Легендарная", "base_price": 800000000, "chance": 0.05, "start_bid": 200000000},
    "Mercedes-Benz 300SL Gullwing": {"stars": 4, "rarity": "Легендарная", "base_price": 850000000, "chance": 0.05, "start_bid": 200000000},
    "Aston Martin Vulcan": {"stars": 4, "rarity": "Легендарная", "base_price": 850000000, "chance": 0.05, "start_bid": 200000000},
    "Pininfarina Battista": {"stars": 4, "rarity": "Легендарная", "base_price": 900000000, "chance": 0.05, "start_bid": 200000000},
    "Rimac Nevera": {"stars": 4, "rarity": "Легендарная", "base_price": 950000000, "chance": 0.05, "start_bid": 200000000},
    
    # ★★★☆☆ Очень редкие
    "Artega GT": {"stars": 3, "rarity": "Очень редкая", "base_price": 60000000, "chance": 0.01, "start_bid": 55000000},
    "Gillet Vertigo": {"stars": 3, "rarity": "Очень редкая", "base_price": 70000000, "chance": 0.01, "start_bid": 55000000},
    "Jensen Interceptor": {"stars": 3, "rarity": "Очень редкая", "base_price": 80000000, "chance": 0.01, "start_bid": 55000000},
    "Bristol Fighter": {"stars": 3, "rarity": "Очень редкая", "base_price": 90000000, "chance": 0.01, "start_bid": 55000000},
    "Maserati Merak": {"stars": 3, "rarity": "Очень редкая", "base_price": 100000000, "chance": 0.01, "start_bid": 55000000},
    "TVR Cerbera": {"stars": 3, "rarity": "Очень редкая", "base_price": 100000000, "chance": 0.01, "start_bid": 55000000},
    "Iso Grifo": {"stars": 3, "rarity": "Очень редкая", "base_price": 110000000, "chance": 0.01, "start_bid": 55000000},
    "Lamborghini Jalpa": {"stars": 3, "rarity": "Очень редкая", "base_price": 120000000, "chance": 0.01, "start_bid": 55000000},
    "Lotus Esprit V8": {"stars": 3, "rarity": "Очень редкая", "base_price": 120000000, "chance": 0.01, "start_bid": 55000000},
    "Morgan Aero 8": {"stars": 3, "rarity": "Очень редкая", "base_price": 120000000, "chance": 0.01, "start_bid": 55000000},
    "Caterham Seven 620R": {"stars": 3, "rarity": "Очень редкая", "base_price": 120000000, "chance": 0.01, "start_bid": 55000000},
    "Donkervoort D8 GTO": {"stars": 3, "rarity": "Очень редкая", "base_price": 120000000, "chance": 0.01, "start_bid": 55000000},
    "Bizzarrini 5300 GT": {"stars": 3, "rarity": "Очень редкая", "base_price": 130000000, "chance": 0.01, "start_bid": 55000000},
    "Radical SR8": {"stars": 3, "rarity": "Очень редкая", "base_price": 130000000, "chance": 0.01, "start_bid": 55000000},
    "De Tomaso Pantera": {"stars": 3, "rarity": "Очень редкая", "base_price": 140000000, "chance": 0.01, "start_bid": 55000000},
    "KTM X-Bow": {"stars": 3, "rarity": "Очень редкая", "base_price": 140000000, "chance": 0.01, "start_bid": 55000000},
    "Ferrari 308 GTB": {"stars": 3, "rarity": "Очень редкая", "base_price": 150000000, "chance": 0.01, "start_bid": 55000000},
    "Ariel Atom 500": {"stars": 3, "rarity": "Очень редкая", "base_price": 150000000, "chance": 0.01, "start_bid": 55000000},
    "Wiesmann MF5": {"stars": 3, "rarity": "Очень редкая", "base_price": 150000000, "chance": 0.01, "start_bid": 55000000},
    "Ascari A10": {"stars": 3, "rarity": "Очень редкая", "base_price": 160000000, "chance": 0.01, "start_bid": 55000000},
    "BAC Mono": {"stars": 3, "rarity": "Очень редкая", "base_price": 160000000, "chance": 0.01, "start_bid": 55000000},
    "Ultima GTR": {"stars": 3, "rarity": "Очень редкая", "base_price": 180000000, "chance": 0.01, "start_bid": 55000000},
    "Caparo T1": {"stars": 3, "rarity": "Очень редкая", "base_price": 180000000, "chance": 0.01, "start_bid": 55000000},
    "Keating Berus": {"stars": 3, "rarity": "Очень редкая", "base_price": 180000000, "chance": 0.01, "start_bid": 55000000},
    "Porsche 930 Turbo": {"stars": 3, "rarity": "Очень редкая", "base_price": 200000000, "chance": 0.01, "start_bid": 55000000},
    "Spyker C8": {"stars": 3, "rarity": "Очень редкая", "base_price": 200000000, "chance": 0.01, "start_bid": 55000000},
    "NIO EP9": {"stars": 3, "rarity": "Очень редкая", "base_price": 200000000, "chance": 0.01, "start_bid": 55000000},
    "Trion Nemesis": {"stars": 3, "rarity": "Очень редкая", "base_price": 200000000, "chance": 0.01, "start_bid": 55000000},
    "Gumpert Apollo": {"stars": 3, "rarity": "Очень редкая", "base_price": 220000000, "chance": 0.01, "start_bid": 55000000},
    "Jaguar XJ220": {"stars": 3, "rarity": "Очень редкая", "base_price": 220000000, "chance": 0.01, "start_bid": 55000000},
    "SCG 003": {"stars": 3, "rarity": "Очень редкая", "base_price": 220000000, "chance": 0.01, "start_bid": 55000000},
    "BMW M1": {"stars": 3, "rarity": "Очень редкая", "base_price": 250000000, "chance": 0.01, "start_bid": 55000000},
    "Drako GTE": {"stars": 3, "rarity": "Очень редкая", "base_price": 250000000, "chance": 0.01, "start_bid": 55000000},
    "Noble M600": {"stars": 3, "rarity": "Очень редкая", "base_price": 280000000, "chance": 0.01, "start_bid": 55000000},
    "Czinger 21C": {"stars": 3, "rarity": "Очень редкая", "base_price": 280000000, "chance": 0.01, "start_bid": 55000000},
    "Mercedes-Benz CLK GTR": {"stars": 3, "rarity": "Очень редкая", "base_price": 300000000, "chance": 0.01, "start_bid": 55000000},
    "Apollo Intensa Emozione": {"stars": 3, "rarity": "Очень редкая", "base_price": 300000000, "chance": 0.01, "start_bid": 55000000},
    "Lamborghini Countach 2022": {"stars": 3, "rarity": "Очень редкая", "base_price": 350000000, "chance": 0.01, "start_bid": 55000000},
    "Aspark Owl": {"stars": 3, "rarity": "Очень редкая", "base_price": 500000000, "chance": 0.01, "start_bid": 55000000},
    "Hispano Suiza Carmen": {"stars": 3, "rarity": "Очень редкая", "base_price": 650000000, "chance": 0.01, "start_bid": 55000000},
    "Lotus Evija": {"stars": 3, "rarity": "Очень редкая", "base_price": 850000000, "chance": 0.01, "start_bid": 55000000}
}

# ========== НАСТРОЙКИ АУКЦИОНА ==========
AUCTION_CONFIG = {
    "max_lots": 15,
    "update_interval": 1800,
    "bid_timeout": 1200,
    "default_start_bid": 1000000
}

# ========== ID ФУНКЦИЙ ДЛЯ ОТКЛЮЧЕНИЯ ==========
FUNCTION_IDS = {
    "job_1": "Шахта",
    "job_2": "Ферма",
    "job_3": "Трейдинг",
    "job_4": "Водолаз",
    "menubutton_1": "Работы",
    "menubutton_2": "Донат",
    "menubutton_3": "Форбс",
    "menubutton_4": "Гараж",
    "menubutton_5": "Инвентарь",
    "menubutton_6": "Скупщик",
    "menubutton_7": "Бизнес",
    "menubutton_8": "Казино",
    "menubutton_9": "Статистика",
    "menubutton_10": "Техподдержка",
    "menubutton_11": "Аукцион",
    "casinogame_1": "Кубик",
    "casinogame_2": "Слоты",
    "casinogame_3": "Мины",
    "trading_1": "BTC",
    "trading_2": "WETcoin",
    "trading_3": "NotCoin",
}

logger.info(f"📁 Данные хранятся в: {DATA_DIR}")
logger.info(f"👑 Админы: {ADMIN_IDS}")
